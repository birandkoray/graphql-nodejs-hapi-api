## Setup

```bash
  $ yarn install && open http://localhost:4000 && yarn run start
```

##### Medium: https://medium.com/@wesharehoodies/how-to-setup-a-powerful-api-with-nodejs-graphql-mongodb-hapi-and-swagger-e251ac189649?source=user_profile---------4-------------------
